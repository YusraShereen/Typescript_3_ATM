Just run:
npm run gulp

Read:
http://sravi-kiran.blogspot.com/2015/09/writing-gulpfile-using-typescript.html
http://blog.keithcirkel.co.uk/how-to-use-npm-as-a-build-tool/