Read:
http://www.typescriptlang.org/Handbook#interfaces

Also Read:
https://github.com/Microsoft/TypeScript/pull/3823