# Learning Object Oriented Programming with TypeScript MyBank Console App

In this project you are going to follow this [video](https://www.youtube.com/watch?v=pzZGlU0n2IU) which explains object oriented programming using C# and write the same code in TypeScript.

Create a GitHub repository for the project and submit its URL in the project submission form. 

