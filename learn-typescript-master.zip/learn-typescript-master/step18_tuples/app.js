//Tuple types have the advantage that you can accurately describe the type of an array of mixed types
var tuple = [1, "bob"];
var secondElement = tuple[1]; // secondElement now has type 'string' 
