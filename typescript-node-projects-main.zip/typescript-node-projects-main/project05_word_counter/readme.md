# Word Counter

The user will enter a english paragraph and all that is needed is to just to implement counting characters and words without whitespaces.

Create a GitHub repository for the project and submit its URL in the project submission form. 