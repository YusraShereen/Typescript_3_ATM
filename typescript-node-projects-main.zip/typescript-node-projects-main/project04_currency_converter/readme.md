# Currency Converter

The TypeScript console app is used to convert currencies: the users enter a certain amount of money in one currency and set the currency they want to check the monetary value of.

While developing the app, the beginners can master variables, algorithms, loops, if statements, and other TypeScript concepts.

Create a GitHub repository for the project and submit its URL in the project submission form. 

