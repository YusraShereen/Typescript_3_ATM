Read:
http://blogs.msdn.com/b/typescript/archive/2014/11/12/announcing-typescript-1-3.aspx
http://fjanon.blogspot.com/2015/05/tuples-and-destructuring-in-typescript.html