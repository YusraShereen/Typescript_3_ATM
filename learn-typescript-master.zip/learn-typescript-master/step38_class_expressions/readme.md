Read:
http://blogs.msdn.com/b/typescript/archive/2015/09/16/announcing-typescript-1-6.aspx

https://github.com/Microsoft/TypeScript/issues/497

https://github.com/Microsoft/TypeScript/pull/3516