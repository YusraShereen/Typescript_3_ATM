# Text-Based Adventure-Game in TypeScript and Node.js

This project is not GUI based. It is a console-based game. The video [here](https://www.youtube.com/watch?v=EpB9u4ItOYU&t=1s) shows how to develop the game in Java. You will take the requirements of the game from the video and develop the game in TypeScript and Node.js

Create a GitHub repository for the project and submit its URL in the project submission form. 

