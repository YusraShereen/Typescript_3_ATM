function add(x, y) {
    return x + y;
}
var myAdd1 = function (x, y) {
    return x + y;
};
var myAdd2 = function (x, y) {
    return x + y;
};
var myAdd3 = function (x, y) {
    return x + y;
};
var myAdd4 = function (a, b) { return a + b; }; //Lambda functions
//output will be: var myAdd4 = function(a : number, b : number) {return a + b};
