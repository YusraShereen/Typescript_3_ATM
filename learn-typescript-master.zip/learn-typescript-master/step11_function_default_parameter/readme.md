Functions with default parameters in chapter 2 of Mastering TypeScript book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also Read:
http://www.typescriptlang.org/Handbook#functions-optional-and-default-parameters
