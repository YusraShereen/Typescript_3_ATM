http://blogs.msdn.com/b/typescript/archive/2015/09/16/announcing-typescript-1-6.aspx
http://stackoverflow.com/questions/32713452/user-defined-type-guards-typescript