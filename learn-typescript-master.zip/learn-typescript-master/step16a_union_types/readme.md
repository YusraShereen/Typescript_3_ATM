Read the unions section in the chapter 2 of Mastering TypeScript Book 
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also read:
http://blogs.msdn.com/b/typescript/archive/2014/11/18/what-s-new-in-the-typescript-type-system.aspx
http://blogs.msdn.com/b/typescript/archive/2015/01/16/announcing-typescript-1-4.aspx