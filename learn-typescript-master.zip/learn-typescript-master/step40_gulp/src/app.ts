class Hello{
	print(){
		console.log("Hello Gulp");
	}
}
var h = new Hello();
h.print();
