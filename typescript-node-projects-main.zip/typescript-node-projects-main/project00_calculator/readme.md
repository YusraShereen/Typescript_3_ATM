# Simple Command Line Calculator

Develop a simple command line calculator using [TypeScipt](https://www.typescriptlang.org/), [Node.js](https://nodejs.org/en/) and [Inquirer](https://www.npmjs.com/package/inquirer).

Create a GitHub repository for the project and submit its URL in the project submission form. 