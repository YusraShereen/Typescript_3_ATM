Please note that in 1.6 the concept of Duck Typing has changed a bit:
https://github.com/Microsoft/TypeScript/pull/3823

Read Duck typing in chapter 2 of Mastering TypeScript book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/
https://tutorialstown.com/duck-typing-in-typescript/

Also read:
https://en.wikipedia.org/wiki/Duck_typing#Criticism
http://ericlippert.com/2014/01/02/what-is-duck-typing/comment-page-1/
