# OOP Introduction Explained with a TypeScript Console Application

In this project you are going to follow this [video](https://www.youtube.com/watch?v=QboWn0NOUA8) which explains object oriented programming using C# and write the same code in TypeScript.

Create a GitHub repository for the project and submit its URL in the project submission form. 

