Read:
http://www.typescriptlang.org/Handbook#classes-advanced-techniques