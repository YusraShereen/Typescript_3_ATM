Read:
https://visualstudiomagazine.com/articles/2015/02/01/datatyping-in-typescript.aspx
http://www.typescriptlang.org/Handbook#classes-inheritance
http://www.johnpapa.net/typescriptpost3/