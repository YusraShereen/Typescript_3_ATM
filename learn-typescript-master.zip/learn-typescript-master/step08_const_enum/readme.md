Enums in chapter 2 of Mastering TypeScript book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also Read:
http://www.typescriptlang.org/Handbook#basic-types-enum
https://basarat.gitbooks.io/typescript/content/docs/enums.html
