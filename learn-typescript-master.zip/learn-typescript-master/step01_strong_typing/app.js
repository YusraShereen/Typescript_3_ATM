//strongly typed syntax
var a = "Pakistan";
a = "USA";
var b = 9;
var c = true;
//type inference
var e = "USA";
var f = 10.9;
f = 22;
var g = false;
g = true;
