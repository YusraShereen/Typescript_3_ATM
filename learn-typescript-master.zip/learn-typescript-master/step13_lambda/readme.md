Read about lambda's from:
http://basarat.gitbooks.io/typescript/content/docs/arrow-functions.html
https://basarat.gitbooks.io/typescript/content/docs/arrow-functions.html
http://laubplusco.net/3-reasons-typescript-brilliant/
https://codepiphany.wordpress.com/2013/02/13/typescript-arrow-functions-getting-the-point/
http://www.typescriptlang.org/Handbook#functions-lambdas-and-using-39this39
http://stackoverflow.com/questions/13934070/can-i-access-the-other-this-in-a-typescript-lambda