export default class Human{
	name : string;
	
	constructor(){
		this.name = "zia";
	}
}