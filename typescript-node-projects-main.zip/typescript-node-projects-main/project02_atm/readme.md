# ATM

This somewhat complex TypeScript/Node.js project is a console-based application. When the system starts the user is prompted with a user id and user pin. After entering the details successfully, the ATM functionalities are unlocked. All the user data is generated randomly. 

Create a GitHub repository for the project and submit its URL in the project submission form. 