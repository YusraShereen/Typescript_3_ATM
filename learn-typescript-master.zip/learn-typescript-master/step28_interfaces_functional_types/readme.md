Read:
http://www.typescriptlang.org/Handbook#interfaces-function-types