//Type aliases are exactly the same as their original types; they are simply alternative names.
//You can use type aliases any where you can use a type
function work(x) {
}
function usingCallback(f) {
    f("This is a string");
}
