# Quiz System

The app will show the students multiple choice questions and promt the user to reply. In the end it will show the students the result of the quiz.

Create a GitHub repository for the project and submit its URL in the project submission form. 