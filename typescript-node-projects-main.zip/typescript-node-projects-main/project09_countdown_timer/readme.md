# Countdown Timer

In this project, you will build a countdown timer using the [date module](https://usefulangle.com/post/187/nodejs-get-date-time).

Create a GitHub repository for the project and submit its URL in the project submission form. 


