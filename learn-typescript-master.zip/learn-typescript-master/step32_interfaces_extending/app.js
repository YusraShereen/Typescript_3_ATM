var square = {};
square.color = "blue";
square.sideLength = 10;
square.a = 5; //Error
var square1 = {}; //Alternative syntax for casting
square1.color = "blue";
square1.sideLength = 10;
square1.penWidth = 5.0;
