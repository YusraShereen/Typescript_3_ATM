tsc app.ts -target es5

Read:
http://www.typescriptlang.org/Handbook#classes-accessors
http://www.codebelt.com/typescript/javascript-getters-setters-typescript-accessor-tutorial/
http://en.wikipedia.org/wiki/Encapsulation_%28object-oriented_programming%29