Read the function overloads section in the chapter 2 of Mastering TypeScript Book 
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/

Also read:
http://www.typescriptlang.org/Handbook#functions-overloads