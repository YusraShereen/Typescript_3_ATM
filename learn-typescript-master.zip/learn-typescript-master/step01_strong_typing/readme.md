Read typing syntax in chapter 2 of Mastering TypeScript Book:
http://www.amazon.com/Mastering-TypeScript-Nathan-Rozentals/dp/1784399663/
Also read:
http://www.typescriptlang.org/Handbook#basic-types